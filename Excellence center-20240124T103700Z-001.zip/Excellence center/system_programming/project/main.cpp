#include"test.h"
#include <iostream>

int main() {
    std::cout << "Hello World!" << "\n";
    foo();
    return 0;
}
