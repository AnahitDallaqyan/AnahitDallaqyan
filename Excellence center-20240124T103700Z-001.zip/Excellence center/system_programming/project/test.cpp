#include<iostream>
#include"test.h"

void foo () {
    std::cout << "Hello from static library" << "\n";
}
