#include "div.h"

float divv (float a, float b) {
    return a/b;
}
