#ifndef DIFF_H
#define DIFF_H

int diff (float a, float b);

#endif

