#ifndef ADD_H
#define ADD_H

int add (float a, float b);

#endif
