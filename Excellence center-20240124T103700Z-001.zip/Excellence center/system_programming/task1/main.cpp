#include <iostream>
#include "add.h"
#include "diff.h"
#include "mul.h"
#include "div.h"

int main () {
    float add_result = add(50,5);
    float diff_result = diff(50,5);
    float mul_result = mul(50,5);
    float div_result = divv(50, 5);
    std::cout << "The addition = " << add_result << "\n";
    std::cout << "The difference = " << diff_result << "\n";
    std::cout << "The multipliaction = " << mul_result << "\n";
    std::cout << "The division = " << div_result << "\n";
    return 0;
}

