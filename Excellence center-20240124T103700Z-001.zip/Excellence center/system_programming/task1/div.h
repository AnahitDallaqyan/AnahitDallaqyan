#ifndef DIV_H   
#define DIV_H

float divv(float a, float b);

#endif
