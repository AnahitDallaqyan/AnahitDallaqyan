#include "add.h"

int add (float a, float b) {
    return a+b;
}
