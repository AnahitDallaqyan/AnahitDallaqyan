#ifndef MUL_H
#define MUL_H

int mul (float a, float b);

#endif

