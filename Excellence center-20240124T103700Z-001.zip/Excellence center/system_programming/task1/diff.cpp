#include "diff.h"

int diff (float a, float b) {
    return a-b;
}

