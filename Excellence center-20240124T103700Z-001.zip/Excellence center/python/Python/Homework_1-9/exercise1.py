'''
    Given list is  [10, 20, 33, 46, 55]
    Divisible by 5
    10
    20
    55
'''

input_list = [10, 20, 33, 46, 55]
for i in input_list:
    if i%5 == 0:
        print(i)