num1 = int(input('Enter the first number: '))
num2 = int(input('Enter the second number: '))

diff = num1 - num2
if diff == 0:
    print('The numbers are equal')
while diff != 0:
    diff = diff + 1
    
if diff == 0:
        print(f"{num2} is greater than {num1}")
else:
        print(f"{num1} is greater than {num2}")
