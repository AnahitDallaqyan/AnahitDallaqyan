#include <iostream>

void count () {
	static int x = 0;
	std::cout << x;
	++x;
	std::cout << x;
}

int main () {
	count();
	count();
	count();
	return 0;
}
