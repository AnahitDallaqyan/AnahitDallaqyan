#include <iostream>
#include <cstring>

class human {
	public:
		char* name;
		char* lastname;
		size_t age;
//member-function		
		void print () {
			std::cout << name << "\n" << lastname << "\n" << age << "\n";
}
//default-constructor
		human () {
			name = new char [20];
			lastname = new char [20];
			size_t age;
		}
//constuctor 
		human (const char* h_name, const char* h_lastname, size_t h_age){
			name = strdup(h_name);
			lastname = strdup(h_lastname);
			age = h_age;
		} 
//copy constructor 
        human (const human &other) {
            name = other.name;
            lastname = other.lastname;
            age = other.age;

        }

//destructor 
		~human() {
			delete [] name;
			delete [] lastname;
		}
};

	int main () {
		human second("Tedy", "Duncan", 15);
		second.print();
		human obj = second;
		obj.print();
		return 0;

	}
