#include <iostream>

int readnum () {
	std::cout << "Enter the number: ";
	int x;
	std::cin >> x;
	return x;
}
void writeanswer (int x) {
	std::cout << "Tne sum of numbers: " <<  x << "\n";
}

int main () {
int x =	readnum();
int y = readnum();
	writeanswer(x+y);
	return 0;
}
