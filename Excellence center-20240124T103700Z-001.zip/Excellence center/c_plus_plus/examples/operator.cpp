#include <iostream>

class A {
	public:
		int x, y ;
		A(int a, int b) {
			x = a;
			y = b;
		};
		A operator / (A c) {
		    int result = (x / y) / (c.x / c.y);
            std::cout << "a / b = "<< result << "\n";
			return A(result,1);
		}
		A (const A& c){
			this -> x = c.x;
			this -> y = c.y;
		}
};

int main () {
	int x1, y1, x2, y2;

    std::cout << "Enter the first x: ";
    std::cin >> x1;
    std::cout << "Enter the first y: ";
    std::cin >> y1;

    std::cout << "Enter the second x: ";
    std::cin >> x2;
    std::cout << "Enter the second y: ";
    std::cin >> y2;
	
	A a1(x1,y1);
	A a2(x2,y2);
	A result = a1 / a2;

	return 0;

}
