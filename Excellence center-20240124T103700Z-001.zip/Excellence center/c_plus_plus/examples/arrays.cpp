#include <iostream>

int main () {
int arr[5] = {10, 20 ,4};
std::cout << arr[2]<< "\n";
std::cout << sizeof(arr) << "\n";
std::cout << sizeof(arr[2]) << "\n"; 
std::cout << arr << "\n";
std::cout << &arr[0] << "\n";
std::cout << *arr << "\n";
char name[] = {"Jason"};
std::cout << *name << "\n";
return 0;
}
